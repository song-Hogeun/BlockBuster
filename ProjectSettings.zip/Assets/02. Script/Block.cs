using System;
using TMPro;
using UnityEngine;
/// <summary>
/// 블록을 관리하는 스크립트
/// </summary>
public class Block : MonoBehaviour
{
    /// <summary>
    /// <--- 개발 목표 --->
    /// 1. 블록을 아래로 이동 시킴
    /// 2. 블록은 시간이 지날수록 점점 빠르게 내려옴
    /// 3. 블록은 시간이 지날수록 갯수가 적어짐
    /// 4. 블록은 좌우로 내려옴 ( 2개 )
    /// </summary>
    
    /*
        07.18 / 블록 이동, 몇 초마다 블록 이동속도 증가 구현
    */
    
    public TextMeshProUGUI test_TimeText; // ( 테스트 ) 시간을 표시할 텍스트
    public TextMeshProUGUI test_moveSpeedText; // ( 테스트 ) 시간을 표시할 텍스트

    [Header("--- 블록이 복귀/이동할 좌표 값 ---"), Space(5)]
    [SerializeField] private Vector2 restartVec; // 블록이 다시 돌아올 좌표값
    [SerializeField] private Vector2 returnVec; // 블록이 최대로 이동할 수 있는 좌표값
    
    [Header("속도 증가 주기"), Space(5)]
    [SerializeField] private float speedUpTime = 20f; // 블록의 이동속도가 상승될 시간 주기
    private float currentTime; // 현재 진행된 플레이 타임을 담는 변수
    
    [Header("블록 이동속도"), Space(5)]
    [SerializeField] private float applySpeed; // (실제 적용) 블록 이동속도
    private float moveSpeed = 1f; // (기본값) 블록 이동속도

    private void Start()
    {
        // 이동속도 기본 값 적용 (초기화)
        applySpeed = moveSpeed;
    }

    private void Update()
    {
        // 플레이 타임 계산 ( 추후 GameManager 이동? ) 15f는 테스트하기 위해서 곱해줌
        currentTime += Time.deltaTime * 15f;
        
        // ( 테스트 코드 )
        test_TimeText.text = "Time : " + currentTime.ToString($"#");
        test_moveSpeedText.text = "Speed : " + applySpeed;
        
        // 블록 이동
        MoveBlock();
    }

    // 블록 이동 함수
    void MoveBlock()
    {
        // 20초 마다 블록 이동속도 상승.
        if (currentTime >= speedUpTime)
        {
            applySpeed += Mathf.Abs(0.2f); // 이동속도 0.2 증가
            currentTime = 0f; // 타이머 초기화
        }
        
        if (transform.position.y <= returnVec.y) // returnVec을 넘어서거나 같아질 때
            transform.position = restartVec; // 오브젝트의 위치를 restartVec으로 설정
        
        else // returnVec의 값을 넘어서지 않았을 때
            transform.position += Vector3.down * applySpeed * Time.deltaTime; // 아래로 이동
    }
}
