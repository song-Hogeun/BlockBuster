using System;
using System.Collections.Generic;
using UnityEngine;

public class ObjectPool : MonoBehaviour
{
    public static ObjectPool Instance;
    
    [SerializeField] private GameObject blockPrefab; // 생성할 블록 프리팹
    Queue<Block> poolingObjectQueue = new Queue<Block>(); // 블록을 순서대로 관리하기 위한 Queue

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        Init(10);
    }

    // 초기 설정
    private void Init(int initCount)
    {
        for (int i = 0; i < initCount; i++) // initCount(10)까지 반복
        {
            poolingObjectQueue.Enqueue(CreateBlock()); // 큐에 생성된 블록을 넣음
        }
    }

    // 블록 생성 로직
    private Block CreateBlock()
    {
        var newObj = Instantiate(blockPrefab).GetComponent<Block>(); // 블록 생성 후, Block 컴포넌트 가져옴
        newObj.gameObject.SetActive(false); // 미리 게임 오브젝트를 비활성화 시켜둠
        newObj.transform.SetParent(transform); // 
        return newObj;
    }
    
    public static Block GetObject()
    {
        if(Instance.poolingObjectQueue.Count > 0)
        {
            var obj = Instance.poolingObjectQueue.Dequeue();
            obj.transform.SetParent(null);
            obj.gameObject.SetActive(true);
            return obj;
        }
        else
        {
            var newObj = Instance.CreateBlock();
            newObj.gameObject.SetActive(true);
            newObj.transform.SetParent(null);
            return newObj;
        }
    }
}
